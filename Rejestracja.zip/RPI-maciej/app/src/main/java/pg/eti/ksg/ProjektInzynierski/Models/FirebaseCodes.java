package pg.eti.ksg.ProjektInzynierski.Models;

public class FirebaseCodes {
    public static final int newFriend = 1;
    public static final int startDangerRoute = 2;
    public static final int newPoint = 3;
    public static final int newInvitation = 4;
    public static final int newMessage = 5;
}
